## 允许google搜索爬取该网站
- 使用谷歌搜索'site:https://kangjie-che.github.io'，应该会显示没有结果
- 前往[谷歌网站验证](https://search.google.com/search-console?hl=zh-CN)，进行设置，允许google爬取该网站
- 选择URL prefix（网址前缀）方式，填写`https://kangjie-chen.github.io`
- 建议选择HTML文件验证方法：有多种方式，建议直接选择`HTML文件`验证方式：下载html文件，上传至repo的根目录，等待网站编译完成。然后点击谷歌网站验证中的`验证`即可。

[reference](https://zhuanlan.zhihu.com/p/129022264)

## 允许百度搜索爬取网站
- 前往[百度网页提交](https://ziyuan.baidu.com/site/index)
- 添加网站，需要填写姓名，联系方式，QQ，微信等。
